from .base import Shape
from .circle import Circle
from .triangle import Triangle
